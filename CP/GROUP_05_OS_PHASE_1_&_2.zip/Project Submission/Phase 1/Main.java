package com.company;

public class Main {

    public static void main(String[] args) {
	// PLEASE CHANGE THE PATH OF INPUT OUTPUT FILE AS YOUR FILE (NOTE BY PRANAV_SANGAVE(31) & GROUP_5 | VIT PUNE)
        OS ourOS =new OS("Input.txt","output.txt");
        ourOS.LOAD();
    }
}
