import java.util.Random;

public class Main {
    public static void main(String[] args) {
// PLEASE CHANGE THE PATH OF INPUT OUTPUT FILE AS YOUR FILE (NOTE BY PRANAV_SANGAVE(31) & GROUP_5 | VIT PUNE)
        OS os = new OS("input.txt","output.txt");
        os.load();
    }
}