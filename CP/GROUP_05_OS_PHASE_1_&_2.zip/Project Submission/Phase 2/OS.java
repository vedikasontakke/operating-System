import jdk.nashorn.internal.ir.Terminal;

import javax.crypto.spec.PSource;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLOutput;
import java.util.Arrays;
import java.util.Random;
import java.util.UUID;

public class OS {

    /** For File Handling */
    private String input_file;
    private String output_file;
    private FileReader input;
    private BufferedReader fread;
    private FileWriter output;

    /*Memory*/
    char M[][] = new char[300][4];
    char buffer[] = new char[40];
    char IR[] = new char[4];
    char R[] = new char[5];
    int IC;
    int C;
    int SI;
    int PI;
    int TI;
    int PTR;
    boolean breakFlag;

    /** Nested class for Process Control Block */
    class PCB
    {
        int job_id;
        int TTL;
        int TLL;
        int TTC;
        int LLC;

        PCB(int job_id, int TTL, int TLL)
        {
            this.job_id = job_id;
            this.TTL = TTL;
            this.TLL = TLL;
            this.TTC = 0;
            this.LLC = 0;
        }
    }


    // Reference of PCB
    OS.PCB pcb;

    // Array of error
    String error[] = new String[]{"No Error", "Out of Data", "Line Limit Exceeded", "Time Limit Exceeded",
            "Operation Code Error", "Operand Error", "Invalid Page Fault"};


    /** Constructor to initialize object data */
    public OS(String file,String output){
        this.input_file=file;
        this.SI=0;
        try {
            this.input = new FileReader(file);
            this.fread= new BufferedReader(input);
            this.output=new FileWriter(output);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // ACTUAL MEMBER FUNCTIONS FROM HERE --------------------------
    void init(){
        for(int i=0; i<M.length; i++){
            for(int j=0; j<M[0].length; j++) {
                M[i][j] = '\0';
            }
        }

        for(int i=0; i<4; i++) {
            IR[i] = '\0';
            R[i] = '\0';
        }

        C = 0;
        SI = 0;
        PI = 0;
        TI = 0;
        breakFlag = false;
    }

    public void printMemory()
    {
        System.out.println("PRINTING MEMORY....");
        for(int i=0; i<300; i++) {
            System.out.print("M["+i+"] = ");
            for(int j=0; j<4; j++)
            {
                System.out.print(M[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println("END PRINTING MEMORY....");
    }


    /** Allocate Method */
    public int allocate() {
        // Generating Random Number
        long longVal = Math.abs(UUID.randomUUID().getMostSignificantBits()) % (long)30;
        String strVal = longVal + "";
        int randomInt = Integer.parseInt(strVal);
        return randomInt;
    }

    /** ADDRESS_MAP */
    public int addressMap(int VA) {
        if(0 <= VA && VA < 100) {
            int pte = PTR + VA/10;
            System.out.println("aM VA = " + VA + " PTR = " + PTR + " PTE " + pte );
            if(M[pte][0] == '*') {
                PI = 3;
                return 0;
            }
            System.out.println("In addressMap() | VA = " + VA + " PTE = " + pte + " M[pte] = " + String.valueOf(M[pte]));
            String tp = "";
            /** DEBUGING TEST ------------- */
            int z = 0;
            while(M[pte][z] != '*') {
                tp = tp + M[pte][z];
                z++;
            }
            /** DEBUGING TEST OVER ------------- */
            int tpInt = Integer.parseInt(tp);
            System.out.println("RA = " + tpInt);
            return (tpInt * 10) + (VA % 10);
        }
        PI = 2;
        return 0;
    }

    public int mos(int RA) {
        if(TI == 0) {
            if(SI != 0) {
                switch (SI) {
                    case 1:
                        read(RA);
                        break;
                    case 2:
                        write(RA);
                        break;
                    case 3:
                        Terminate(0);
                        breakFlag = true;
                        break;
                    default:
                        System.out.println("ERROR with SI");
                }
                SI = 0;
            } else if (PI != 0) {
                switch (PI) {
                    case 1:
                        Terminate(4);
                        breakFlag = true;
                        break;
                    case 2:
                        Terminate(5);
                        breakFlag = true;
                        break;
                    case 3:
                        PI = 0;
                        // Page fault checking
                        char tpC[] = new char[2];
                        tpC[0] = IR[0];
                        tpC[1] = IR[1];

                        String tpS = new String(tpC);
                        System.out.println("TpS = " + tpS);
                        if (tpS.equals("GD") || tpS.equals("SR")) {
                            int m;
                            do {
                                m = allocate();
                            } while (M[m * 10][0] != '\0');

                            int currPTR = PTR;
                            while (M[currPTR][0] != '*')
                                currPTR++;

                            // Performing : itoa(m, M[currPTR], 10);
                            char mAr[] = (m + "").toCharArray();
                            for (int i = 0; i < mAr.length; ) {
                                M[currPTR][i % 4] = mAr[i];
                                i++;
                                if (i % 4 == 0)
                                    currPTR++;
                            }

                            System.out.println("Valid Page Fault. Page Frame = " + m );
                            System.out.println("PTR = " + PTR);
                            for(int i=0; i<300; i++) {
                                System.out.print("M["+i+"] : ");
                                for(int j=0; j<4; j++) {
                                    System.out.print(M[i][j]);
                                }
                                System.out.println();
                            }
                            System.out.println();

                            if (pcb.TTC + 1 > pcb.TTL) {
                                TI = 2;
                                PI = 3;
                                mos();
                                break;
                            }

                            pcb.TTC++;
                            return 1;
                        } else if (tpS.equals("PD") || tpS.equals("LR") || tpS.equals("H") || tpS.equals("CR") || tpS.equals("BT")) {
                            Terminate(6);
                            breakFlag = true;

                            if (pcb.TTC + 1 > pcb.TTL) {
                                TI = 2;
                                PI = 3;
                                mos();
                                break;
                            }
                        } else {
                            PI = 1;
                            mos();
                        }

                        return 0;
                    default:
                        System.out.println("Error with PI.");
                }
                PI = 0;
                }
        }
        else {
            if(SI != 0) {
                switch (SI) {
                    case 1:
                        Terminate(3);
                        breakFlag = true;
                        break;
                    case 2:
                        write(RA);
                        if(breakFlag) Terminate(3);
                        break;
                    case 3:
                        Terminate(0);
                        breakFlag = true;
                        break;
                    default:
                        System.out.println("Error with SI");
                }
                SI = 0;
            }
            else if(PI != 0) {
                switch (PI) {
                    case 1:
                        Terminate(3,4);
                        breakFlag = true;
                        break;
                    case 2:
                        Terminate(3,5);
                        breakFlag = true;
                        break;
                    case 3:
                        Terminate(3);
                        breakFlag = true;
                        break;
                    default:
                        System.out.println("Error with PI.");
                }
                PI = 0;
            }
        }

        return 0;
    }

    /** TERMINATE FUNCTION */
    public void Terminate(int EM, int EM2) {
        try {
            output.write("\n\n");
            if (EM == 0) {
                System.out.println("Terminated Normally. " + error[EM] + "\n");
                output.write("Terminated Normally. " + error[EM] + "\n");
            }
            else {
                output.write("Terminated Abnormally Due To " + error[EM] + ((EM2 != -1) ? ("."+error[EM2]) : "") + "\n");
                System.out.println("Terminated Abnormally Due To " + error[EM] + ((EM2 != -1) ? ("."+error[EM2]) : "") + "\n");
                output.write("IC = " + String.valueOf(IC));
                output.write("\nEM = " + EM + " EM2 = " + EM2);
                output.write("IR = " + String.valueOf(IR));
                System.out.println("IR = " + String.valueOf(IR));
                output.write("R = " + String.valueOf(R));
                output.write("C = " + String.valueOf(C));
                output.write("TTL = " + pcb.TTL);
                output.write("TTC = " + pcb.TTC);
                output.write("TLL = " + pcb.TLL);
                output.write("LLC = " + pcb.LLC);
            }
        }catch (Exception e) {
            e.printStackTrace();;
        }
    }

    /** OVERLOADED TERMINATE FUNCTION */
    public void Terminate(int EM) {
        int EM2 = -1;
        try {
            output.write("\n\n");
            if (EM == 0) {
                System.out.println("Terminated Normally. " + error[EM] + "\n");
                output.write("Terminated Normally. " + error[EM] + "\n");
            }
            else {
                output.write("Terminated Abnormally Due To " + error[EM] + ((EM2 != -1) ? ("."+error[EM2]) : "") + "\n");
                System.out.println("Terminated Abnormally Due To " + error[EM] + ((EM2 != -1) ? ("."+error[EM2]) : "") + "\n");
                output.write("\nIC = " + String.valueOf(IC));
                output.write("\nEM = " + EM);
                output.write("\nIR = " + String.valueOf(IR));
                System.out.println("IR = " + String.valueOf(IR));
                output.write("\nR = " + String.valueOf(R));
                output.write("\nC = " + String.valueOf(C));
                output.write("\nTTL = " + pcb.TTL);
                output.write("\nTTC = " + pcb.TTC);
                output.write("\nTLL = " + pcb.TLL);
                output.write("\nLLC = " + pcb.LLC);
            }
        }catch (Exception e) {
            e.printStackTrace();;
        }
    }

    /** READ FUNCTION */
    public void read(int RA) {
        try{
            String line = fread.readLine();
            buffer = line.toCharArray();

            char temp[] = new char[4];
            for(int i=0; i<4; i++) {
                temp[i] = buffer[i];
            }
            String tpS = new String(temp);
            if(tpS.equals("$END")) {
                Terminate(1);
                breakFlag = true;
            }
            else {
                for (int i = 0; i < line.length();) {
                    M[RA][i%4]=buffer[i];
                    i++;
                    if(i%4==0)
                        RA++;
                }
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    /** WRITE FUNCTION */
    public void write(int RA) {
        if(pcb.LLC + 1 > pcb.TLL) {
            Terminate(2);
            breakFlag = true;
        }
        else {
            String writeLine = "";
            int k = 0;
            for(int i = RA; i<(RA+10); i++){
                for(int j =0; j<4; j++){
                    writeLine = writeLine + M[i][j];
                }
            }
            // Writing on file
            try{
                output.write(writeLine);
                pcb.LLC++;
            }catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /** Overloaded mos() for default parameter RA = 0 */
    public boolean mos() {
        int RA = 0;
        if(TI == 0) {
            if(SI != 0) {
                switch (SI) {
                    case 1:
                        read(RA);
                        break;
                    case 2:
                        write(RA);
                        break;
                    case 3:
                        Terminate(0);
                        breakFlag = true;
                        break;
                    default:
                        System.out.println("ERROR with SI");
                }
                SI = 0;
            } else if (PI != 0) {
                switch (PI) {
                    case 1:
                        Terminate(4);
                        breakFlag = true;
                        break;
                    case 2:
                        Terminate(5);
                        breakFlag = true;
                        break;
                    case 3:
                        PI = 0;
                        // Page fault checking
                        char tpC[] = new char[2];
                        tpC[0] = IR[0];
                        tpC[1] = IR[1];

                        String tpS = new String(tpC);
                        System.out.println("tpS = " + tpS);
                        if (tpS.equals("GD") || tpS.equals("SR")) {
                            int m;
                            do {
                                m = allocate();
                            } while (M[m * 10][0] != '\0');

                            int currPTR = PTR;
                            while (M[currPTR][0] != '*')
                                currPTR++;

                            // Performing : itoa(m, M[currPTR], 10);
                            char mAr[] = (m + "").toCharArray();
                            for (int i = 0; i < mAr.length; ) {
                                M[currPTR][i % 4] = mAr[i];
                                i++;
                                if (i % 4 == 0)
                                    currPTR++;
                            }

                            if (pcb.TTC + 1 > pcb.TTL) {
                                TI = 2;
                                PI = 3;
                                mos();
                                break;
                            }

                            pcb.TTC++;
                            return true;
                        } else if (tpS.equals("PD") || tpS.equals("LR") || tpS.equals("H") || tpS.equals("CR") || tpS.equals("BT")) {
                            Terminate(6);
                            breakFlag = true;

                            if (pcb.TTC + 1 > pcb.TTL) {
                                TI = 2;
                                PI = 3;
                                mos();
                                break;
                            }
                        } else {
                            PI = 1;
                            mos();
                        }
                        return false;
                    default:
                        System.out.println("Error with PI.");
                }
                PI = 0;
            }
        }
        else {
            if(SI != 0) {
                switch (SI) {
                    case 1:
                        Terminate(3);
                        breakFlag = true;
                        break;
                    case 2:
                        write(RA);
                        if(breakFlag) Terminate(3);
                        break;
                    case 3:
                        Terminate(0);
                        breakFlag = true;
                        break;
                    default:
                        System.out.println("Error with SI");
                }
                SI = 0;
            }
            else if(PI != 0) {
                switch (PI) {
                    case 1:
                        Terminate(3,4);
                        breakFlag = true;
                        break;
                    case 2:
                        Terminate(3,5);
                        breakFlag = true;
                        break;
                    case 3:
                        Terminate(3);
                        breakFlag = true;
                        break;
                    default:
                        System.out.println("Error with PI.");
                }
                PI = 0;
            }
        }

        return false;
    }
    public void execute_user_program() {
        char temp[] = new char[3];
        char loca[] = new char[2];
        int locIR, RA;

        while(true) {
            if(breakFlag) break;

            RA = addressMap(IC);
            if(PI != 0) {
                if(mos()) {
                    continue;
                }
                break;
            }

            System.out.println("IC = " + IC + " RA = " + RA);
            IR = M[RA];
            IC++;

            // '\0' == NULL
            temp[0] = '\0';
            temp[1] = '\0';

            temp[0] = IR[0];
            temp[1] = IR[1];

            for(int i=0; i<2; i++) {
                if(!((47 < IR[i+2] && IR[i+2] < 58) || IR[i+2] == 0)) {
                    PI = 2;
                    break;
                }
                loca[i] = IR[i+2];
            }

            if(PI != 0) {
                mos();
                break;
            }

            System.out.println("LOCA = " + String.valueOf(loca));
            if(loca[0] == '\0')
                locIR = 0;
            else
                locIR = Integer.parseInt(new String(loca));

            RA = addressMap(locIR);

            if(PI != 0) {
                if(mos()) {
                    IC--;
                    continue;
                }
                break;
            }

            System.out.println("IC = " + IC + " RA = " + RA + " IR = " + String.valueOf(IR));
            if(pcb.TTC + 1 > pcb.TTL) {
                TI = 2;
                PI = 3;
                mos();
                break;
            }

//            String opcode = String.valueOf(temp[0]) + String.valueOf(temp[1]);
            String opcode = "";
            int x = 0;
            while(temp[x] != '\0') {
                opcode = opcode + String.valueOf(temp[x]);
                x++;
            }
            System.out.println("OPCODE = " + opcode + " Equals : " + opcode.equals("GD"));
            if(opcode.equals("LR")) {
                R = M[RA];
                pcb.TTC++;
            }
            else if(opcode.equals("SR")) {
                M[RA] = R;
                pcb.TTC++;
            }
            else if(opcode.equals("CR")) {
                if(Arrays.equals(R,M[RA])) {
                    C = 1;
                }
                else {
                    C = 0;
                }
                pcb.TTC++;
            }
            else if(opcode.equals("BT")) {
                if(C == 1)
                    IC = RA;
                pcb.TTC++;
            }
            else if(opcode.equals("GD")) {
                SI = 1;
                mos(RA);
                pcb.TTC++;
            }
            else if(opcode.equals("PD")) {
                SI = 2;
                mos(RA);
                pcb.TTC++;
            }
            else if(opcode.equals("H")) {
                SI = 3;
                mos();
                pcb.TTC++;
                break;
            }
            else {
                PI = 1;
                mos();
                break;
            }
            IR[0] = '\0';
            IR[1] = '\0';
            IR[2] = '\0';
            IR[3] = '\0';
        }
    }

    /** EXECUTE METHOD */
    public void execute() {
        IC = 0;
        execute_user_program();
    }

    /** Main Method */
    public void load() {
        int m = 0;
        int crntPtr = 0;
        char temp[] = new char[5];

        String line;

        try{
            while((line = fread.readLine()) != null) {
                buffer = line.toCharArray();
                System.out.println("Line = " + line);
                if(buffer[0]=='$'&& buffer[1]=='A'&&buffer[2]=='M'&& buffer[3]=='J') {
                    /**
                     * Post program-card algorithm
                     * ============================
                     * 1. Reset all storage stuff, trackers and counters
                     * 2. Store program commands into memory array
                     *
                     * */
                    System.out.println("Program card detected");

                    init();

                    int jobId, TTL, TLL;
                    /**
                     * 1. Convert buffer value from index 4 to index 7 in Integer as JOB_ID
                     * 2. Convert buffer value from index 8 to index 11 in Integer as TTL
                     * 3. Convert buffer value from index 12 to index 15 in Integer as TLL
                     * */
                    String job_id_str = "";
                    String ttl_str = "";
                    String tll_str = "";
                    for(int i=4; i<8; i++)
                    {
                        job_id_str = job_id_str + buffer[i];
                    }
                    for(int i=8; i<12; i++)
                    {
                        ttl_str = ttl_str + buffer[i];
                    }
                    for(int i=12; i<16; i++)
                    {
                        tll_str = tll_str + buffer[i];
                    }

                    jobId = Integer.parseInt(job_id_str);
                    TTL = Integer.parseInt(ttl_str);
                    TLL = Integer.parseInt(tll_str);

                    pcb = new PCB(jobId, TTL, TLL);

                    PTR = allocate() * 10;

                    System.out.println("PTR: " + PTR);

                    for(int i=PTR; i<PTR+10; i++) {
                        for(int j = 0; j<4; j++) {
                            M[i][j] = '*';
                        }
                    }

                    crntPtr = PTR;
//                    continue;
                }
                else if(buffer[0]=='$'&& buffer[1]=='D'&&buffer[2]=='T'&& buffer[3]=='A') {
                    /**
                     * Post data-card algorithm
                     * ============================
                     * 1. start execution of program in slave mode
                     *
                     * */
                    System.out.println("Data card detected");
                    execute();
                }
                else if(buffer[0]=='$'&& buffer[1]=='E'&&buffer[2]=='N'&& buffer[3]=='D') {
                    continue;
                }
                else {
                    if(breakFlag) continue;

                    do{
                        m = allocate();
                    }while (M[m*10][0] != '\0');

//                    ---- HERE ---
                    String mNum = m + "";
                    char tempAr[] = mNum.toCharArray();
                    int tempCrntPtr = crntPtr;
                    int i=0, j=0;
                    while(i<tempAr.length) {
                        M[tempCrntPtr][j] = tempAr[i];
                        i++;
                        j++;
                        if(j % 4 == 0){
                            j = 0;
                            tempCrntPtr++;
                        }
                    }
                    crntPtr++;

                    // strcpy(M[m*10],buffer);
                    j = 0; i =0;
                    tempCrntPtr = m*10;
                    while(i<buffer.length) {
                        M[tempCrntPtr][j] = buffer[i];
                        i++;
                        j++;
                        if(j % 4 == 0){
                            j = 0;
                            tempCrntPtr++;
                        }
                    }

                    System.out.println("PTR = " + PTR);
                    System.out.println("CRNT PTR = " + crntPtr);
                    System.out.println("M = " + m);
                    printMemory();
                }
            }
            input.close();
            output.close();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

}
